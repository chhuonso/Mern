// CONTROLLER
// making the queries to the DB
// using the model
// so, we have to import the model
const jokes = require('../models/jokes.model')

// make ALL the CRUD


// CRUD
// READ ALL
module.exports.findAllJokes = (req,res) => {
    // use the model to execute a query
    jokes.find()
        .then(allTheJokes => {
            // IMPORTAN what we return here is what we will recevie in REACT!
            res.json({allTheJokes, status: "ok"}) //[] array put into {} object
        })
        .catch(err => res.json({message: "something went wrong", serverError: err}))
}

// CREATE
module.exports.createNewJoke = (req, res) => {
    // db.jokes.insertOne({setup:"", punchline:""})
    jokes.create(req.body)
        .then(newlyCreatedJoke => res.json({ joke: newlyCreatedJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}
// FIND ONE
module.exports.findOneSingleJoke = (req, res) => {
    jokes.findOne({ _id: req.params.id }) //{ findone by MONGO id in our DB==> _id: req.params.id <== variable name we created}
        .then(oneSingleJoke => res.json({ joke: oneSingleJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}


// FIND ONE UPDATE
module.exports.updateExistingJoke = (req, res) => {
    jokes.findOneAndUpdate(
        { _id: req.params.id },
        req.body,
        // this says only return to the newly created object and runValidators if true. BY DEFAULT MONGOS DOES NOT RUN  VALIDATION ON AN UPDATE 
        { new: true, runValidators: true }
    )
        .then(updatedJoke => res.json({ joke: updatedJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}

// DELETE ONE BY ID
module.exports.deleteAnExistingJoke = (req, res) => {
    jokes.deleteOne({ _id: req.params.id })
        .then(result => res.json({ result: result }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}