// import MONGOOSE to build the model
const mongoose = require('mongoose');

// the schema - the rules that the entries in the DB must follow
const JokeSchema = new mongoose.Schema({
    setup: String,
    punchline: String
    
}, {timestamps:true})

// the model- this what we use to make the actual queries to DB
const jokes = mongoose.model("Jokes", JokeSchema)

// export the model 
module.exports = jokes;