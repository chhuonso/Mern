const mongoose = require("mongoose");


module.exports = (DB_name) => {
    
    
    mongoose.connect(`mongodb://localhost/${DB_name}`)
    .then(()=> console.log(`Connect to ${DB_name}`))
    .catch(err => console.log('cant connect to DB_name', err))
    
}