// import the controller to use the INSTANTIATED MODEL
const JokesController = require('../controllers/jokes.controller')
//console.log(JokesController) //import the routes to the DB in SERVER.js

module.exports = (app) => {
    // app.get('/api/jokes', (req, res) => {
    //     res.json(allTheJokes)
    // })
    app.get('/api/jokes', JokesController.findAllJokes)
    app.post('/api/jokes',JokesController.createNewJoke)
    app.get('/api/jokes/:id', JokesController.findOneSingleJoke)
    app.put('/api/jokes/:id', JokesController.updateExistingJoke)
    app.delete('/api/jokes/:id', JokesController.deleteAnExistingJoke)
}

