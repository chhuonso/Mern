const express = require("express");
const app = express();
const port = 8000;
const DB = "jokes";


// MIDDLEWARE 
app.use(express.json(), express.urlencoded({ extended: true }));

// CONNECTED TO THE DATABASE USING MONGOOSE
require("./config/mongoose.config")(DB)

// ------import the routes AFTER the DB connection
require('./routes/jokes.route')(app) // invokes to the Jokes.route.js to pass in

// START THE SERVER takes in the PORT and FUNCTION
app.listen(8000, () => console.log(`The server is all fired up on port ${port}`));